# Adrian's OpenClaw C-Suite Workspace

9 spezialisierte KI-Agenten als dein persönliches C-Suite Team.

## Agenten Übersicht

| Agent | Emoji | Rolle | Kanal | Heartbeat |
|-------|-------|-------|-------|-----------|
| **Max** | ⚡ | CTO — Code, Deployment, Tech | Slack (default) | 4h |
| **Luna** | 🌙 | CMO — Marketing, SEO, Content | Slack | Täglich |
| **Rico** | 💰 | CRO — Sales, Pipeline, Closing | Slack | Täglich |
| **Hunter** | 🎯 | Lead Gen — Cold Outreach | Slack | 8h |
| **Sherlock** | 🔍 | Research — Markt, EU, Wettbewerb | Slack | 2 Tage |
| **Zen** | 🧘 | COO — Operations, Admin | Slack (default) | 8h |
| **Pixel** | 🎨 | CPO — Produkt, UX, Roadmap | Slack | 2 Tage |
| **Neo** | 📊 | Analyst — MRR, KPIs, Zahlen | Slack | Wöchentlich |
| **Ghost** | 👻 | DevOps — Monitoring, Alerts | Background | 4h |

## Deployment

### 1. Workspaces erstellen

```bash
mkdir -p ~/.openclaw/workspace-{max,luna,rico,hunter,sherlock,zen,pixel,neo,ghost,main}
mkdir -p ~/.openclaw/workspace-{max,luna,rico,hunter,sherlock,zen,pixel,neo,ghost,main}/memory
```

### 2. Files kopieren

```bash
# Für jeden Agenten: Ordner aus diesem ZIP in das entsprechende Workspace kopieren
cp -r max/* ~/.openclaw/workspace-max/
cp -r luna/* ~/.openclaw/workspace-luna/
cp -r rico/* ~/.openclaw/workspace-rico/
cp -r hunter/* ~/.openclaw/workspace-hunter/
cp -r sherlock/* ~/.openclaw/workspace-sherlock/
cp -r zen/* ~/.openclaw/workspace-zen/
cp -r pixel/* ~/.openclaw/workspace-pixel/
cp -r neo/* ~/.openclaw/workspace-neo/
cp -r ghost/* ~/.openclaw/workspace-ghost/
cp -r main/* ~/.openclaw/workspace/
```

### 3. openclaw.json einrichten

Die `openclaw.json` in dein OpenClaw Config-Verzeichnis kopieren:

```bash
cp openclaw.json ~/.openclaw/openclaw.json
```

Oder in die bestehende Config mergen.

### 4. Workspaces in OpenClaw konfigurieren

In OpenClaw Settings → Agents: Für jeden Agenten den Workspace-Pfad setzen:
- Max: `~/.openclaw/workspace-max`
- Luna: `~/.openclaw/workspace-luna`
- etc.

## Erste Schritte

### Slack (Max als Default)
Schreib einfach im Slack-Channel oder per Mention: "Hallo Max" bzw. nutze Keyword-Trigger

### Slack (Zen als Ops-Agent)
Zen übernimmt operative Anfragen automatisch in Slack

### Keyword Routing
Die Agenten reagieren auf Keywords automatisch:
- "deploy" → Ghost oder Max
- "lead" → Hunter
- "mrr" → Neo
- "feature" → Pixel
- etc.

## Personalisierung

Jeder Agent hat eigene Files die du anpassen kannst:

- **SOUL.md** — Persönlichkeit und Werte
- **USER.md** — Dein Kontext (wird geteilt, alle Agenten haben es)
- **AGENTS.md** — Workspace-Regeln
- **TOOLS.md** — Technische Details, Stack-Infos
- **HEARTBEAT.md** — Proaktive Checks
- **MEMORY.md** — Langzeitgedächtnis (wächst automatisch)

## Wichtige Regeln

- **Zeitregel**: Donnerstag 15:00–17:30 reduzierte Erreichbarkeit; **Sonntag ist Arbeitstag**
- **Ghost** läuft primär im Background — nur Alarm bei echten Problemen
- **MEMORY.md** wird nur im direkten Chat (Main Session) geladen — in Gruppen nicht
- **USER.md** ist identisch für alle Agenten (eine geteilte Quelle der Wahrheit über dich)

## Files Struktur

```
openclaw.json          ← Haupt-Config für OpenClaw
main/                  ← Shared/General Workspace
  AGENTS.md
  SOUL.md
  USER.md
  TOOLS.md
  MEMORY.md
  HEARTBEAT.md
  IDENTITY.md
max/                   ← CTO Workspace
luna/                  ← CMO Workspace
rico/                  ← CRO Workspace
hunter/                ← Lead Gen Workspace
sherlock/              ← Research Workspace
zen/                   ← COO Workspace (Slack)
pixel/                 ← CPO Workspace
neo/                   ← Analyst Workspace
ghost/                 ← DevOps Workspace
```
