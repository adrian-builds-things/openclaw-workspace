# SyncThing Markdown Spiegel – Anleitung

## Was ist eingerichtet?
- Alle `.md`-Dateien aus dem Workspace werden nach
  - `/home/adrian/Sync/openclaw-workspace-md`
  gespiegelt.

## Manuell ausführen
```bash
cd /home/adrian/.openclaw/workspace
./scripts/syncthing_md_sync.sh
```

## Automatisch
- Cron-Job aktiv: **alle 10 Minuten**
- Job-Name: `SyncThing MD Spiegelung (alle 10 Min)`

## Prüfen
```bash
ls -la /home/adrian/Sync/openclaw-workspace-md
```
Wenn neue `.md` im Workspace erstellt wurden, sollten sie dort erscheinen.
