# Adrian Command Dashboard

Stand: 2026-02-16 11:xx UTC

## 1) Schnellzugriff (wichtigste Links)

### Live App
- Adrian Ops (lokal auf Server): http://127.0.0.1:3011
- Adrian Ops (auf deinem Mac via Tunnel): http://localhost:3011
- Tunnel-Befehl:
  - `ssh -N -L 3011:127.0.0.1:3011 adrian@100.78.193.125`

### Produkte
- Bite Club: https://www.bite-club.app
- MindTrajour: https://www.mindtrajour.com

### OpenClaw Dashboard Tunnel (Mac)
- `ssh -N -L 18789:127.0.0.1:18789 adrian@100.78.193.125`
- `http://localhost:18789/?token=DEIN_TOKEN`

---

## 2) Was bereits gebaut wurde (Assets)

### Growth / Sales Assets
- `plans/biteclub/icp-offer-pricing-decision.md`
- `plans/biteclub/outreach-pack.md`
- `plans/sales/daily-revenue-scoreboard-template.md`
- `plans/sales/revenue-scoreboard-workflow.md`

### Neu heute (proaktiv)
- `plans/biteclub/linkedin-content-engine.md`
- `plans/knowledge/obsidian-local-knowledge-bridge.md`
- `plans/ops/work-log.md`

### Task Source of Truth
- `plans/tasks-master.md`

---

## 3) Repos & Branch-Status

### Workspace Repo (`/home/adrian/.openclaw/workspace`)
- Aktuelle Branch: `feat/unified-task-dashboard`
- Relevante Commits:
  - `4bde6b2` – unified master task dashboard
  - `1d74794` – Bite Club growth assets + scoreboard workflow

### adrian-ops Repo (`/home/adrian/.openclaw/workspace/tools/adrian-ops`)
- Aktuelle Branch: `feat/ux-v3-dnd-clarity`
- Branch `feat/nextjs-shadcn-rebuild` zeigt auf denselben aktuellen Commit
- Relevante Commit-Historie:
  - `8a0dcfb` – UX/DnD clarity
  - `0a60568` – Next.js + shadcn rebuild
  - `37b4e0d` – IA + Kanban + Timeboxing redesign
  - `4ef047b` – UX contrast improvements
  - `ac729b3` – master tasks dashboard
  - `6e6267f` – inbox + transcript extractor

---

## 4) Heute offen (fokussiert)

1. **UI Stabilität & Nutzbarkeit finalisieren**
   - kognitive Last weiter runter
   - klare Prioritäts-Ansicht + vollständige Gesamtliste
2. **LinkedIn Engine operationalisieren**
   - 2-Wochen Plan fixieren (6 Posts + 2 Blog-Entwürfe)
3. **Wissensmanagement MVP starten**
   - Obsidian lokal anbinden (ohne Cloud)
   - Struktur + täglicher Digest-Prozess

---

## 5) Entscheidungen, die von dir gebraucht werden

1. **Canonical Branch für adrian-ops:**
   - `feat/ux-v3-dnd-clarity` (aktuell) als Hauptbasis behalten?
2. **Obsidian Setup:**
   - Option A: Vault im Workspace
   - Option B: bestehender Vault + Symlink
3. **Content-Tonality Bite Club:**
   - eher founder-persönlich / provokant
   - oder sachlich-operativ / template-lastig

---

## 6) Arbeitsbuch / Tracking

- Laufendes Buch: `plans/ops/work-log.md`
- Tagesnotizen: `memory/2026-02-16.md`
- Langzeitgedächtnis: `MEMORY.md`

---

## 7) Wenn du nur 30 Sekunden hast

- App läuft auf **3011**
- Alles Wichtige liegt in **DASHBOARD.md** + **work-log.md**
- Nächster Hebel für Umsatz: **LinkedIn Content Engine aktiv schalten**

<!-- TOOLS_SECTION_START -->
## 8) Eigene Tools (Dashboard-Rubrik)

Diese Tools wurden von Manne gebaut/registriert:

- **adrian-ops** → `tools/adrian-ops/README.md`
- **outreach-machine** → `tools/outreach-machine/README.md`

_Hinweis: Rubrik wird automatisch aktualisiert via `scripts/update_dashboard_tools_section.py`._
<!-- TOOLS_SECTION_END -->
